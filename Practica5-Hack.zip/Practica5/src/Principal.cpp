/** 
*	Programa principal para navegacion
*/

#include "ControlRobot.h"
#include "Laberinto.h"

using namespace std;


/*funcion de control remoto, el robot se movera segun lo indicado a traves del teclado*/
void recorrerLaberintoManual(){
	/*
	Laberinto *maze_grid;
	maze_grid = new Laberinto("../xml/Rejilla.xml");
	maze_grid->imprimirLaberinto();
	*/

	bool fin = false;
        
        ControlRobot robot;
        robot.inicializacion();
        
	Laberinto *maze;
	maze = new Laberinto("./xml/Laberinto.xml");
	maze->imprimirLaberinto();
        

        
	string teclas;
	while(!fin){
		cin >> teclas;

		char orientacion;
		int x,y;
		
		//si se desea orientar al norte
		if(teclas.compare("n")==0){
			/*se analiza la orientacion del robot y partiendo de esta informacion
			se indica al robot que funcion debe realizar para llegar al objetivo*/
                    switch(orientacion){
                        case(SUR):
                            robot.gira180();
                            break;       
                        case(ESTE):
                            robot.giraIzquierda();
                            break;        
                        case(OESTE):
                            robot.giraDerecha();
                            break;
                        default:
                            break;
                        }
						//se orienta el robot en el laberinto imprimido en pantalla
			maze->orientarRobotNorte(); 
			
			//si se desea orientar al sur
		}else if(teclas.compare("s")==0){
                    switch(orientacion){
                        case(NORTE):
                            robot.gira180();
                            break;       
                        case(ESTE):
                            robot.giraDerecha();
                            break;        
                        case(OESTE):
                            robot.giraIzquierda();
                            break;
                        default:
                            break;
                        }
			maze->orientarRobotSur();
			
			//si se desea orientar al este
		}else if(teclas.compare("e")==0){
                    switch(orientacion){
                        case(SUR):
                            robot.giraIzquierda();
                            break;       
                        case(NORTE):
                            robot.giraDerecha();
                            break;        
                        case(OESTE):
                            robot.gira180();
                            break;
                        default:
                            break;
                        }
			maze->orientarRobotEste();
			
			//si se desea orientar al oeste
		}else if(teclas.compare("w")==0){
                    switch(orientacion){
                        case(SUR):
                            robot.giraDerecha();
                            break;       
                        case(ESTE):
                            robot.gira180();
                            break;        
                        case(NORTE):
                            robot.giraIzquierda();
                            break;
                        default:
                            break;
                        }
			maze->orientarRobotOeste();
			
			//si se desea avanzar
		}else if(teclas.compare("g")==0){

			maze->getPosRobot(&x,&y,&orientacion);
			
			/*se comprueba si existe realmente el camino de nuevo*/
			switch(orientacion){
			case NORTE:
				if(maze->esNorteLibre()){
					maze->avanzaNorte();  
				}else{
					cout << "No existe un camino en la actual orientacion "<< endl;
				}
				break;
			case SUR:
				if(maze->esSurLibre()){
					maze->avanzaSur();
				}else{
					cout << "No existe un camino en la actual orientacion "<< endl;
				}
				break;
			case ESTE:
				if(maze->esEsteLibre()){
					maze->avanzaEste();
				}else{
					cout << "No existe un camino en la actual orientacion "<< endl;
				}
				break;
			case OESTE:
				if(maze->esOesteLibre()){
					maze->avanzaOeste();
				}else{
					cout << "No existe un camino en la actual orientacion "<< endl;
				}
				break;
			default:
				break;
			}
			
			/*se inicia el autoguiado en linea recta hasta el siguiente nodo*/
                            robot.leerSensores();//se traspasa el nodo actual
                            robot.logicaEstados();
                            robot.moverActuadores();
							
						/*el robot avanza mediante autoguiado hasta encontrar el siguiente nodo*/
                        while(!robot.condicionSalida()){
                            robot.leerSensores();
                            robot.logicaEstados();
                            robot.moverActuadores();
                        }
						
							//se centra el robot en el nodo encontrado
                            robot.para();
		}else if(teclas.compare("salir")==0){
			fin = true;
		}else if(teclas.compare("imprimir")==0){
			maze->imprimirCaminoRobot();
		}else{
			cout<<"comando: "<<teclas<<" no reconocido"<<endl;
		}
                

		maze->getPosRobot(&x,&y,&orientacion);

		if(x==5 & y==5){
			cout << "Has llegado al otro extremo del laberinto!"<<endl;
			fin = true;
		}
		maze->imprimirLaberinto();
	}
	
	maze->imprimirCaminoRobot();
	
	cout << "finaliza el programa" << endl;
}

void recorrerCamino(camino *solucion, Laberinto *maze){
	/*
	Laberinto *maze_grid;
	maze_grid = new Laberinto("../xml/Rejilla.xml");
	maze_grid->imprimirLaberinto();
	*/

	bool fin = false;
        
        ControlRobot robot;
        robot.inicializacion();
        char orientacion;
	int x,y;
  
	struct camino* aux = solucion;
          

	while(aux->siguiente!=NULL && !fin){
            
            cout<<"nodo: x "<<aux->nodo_actual->x<< "y "<< aux->nodo_actual->y<<endl;

		if(aux->nodo_actual->x == aux->siguiente->nodo_actual->x && aux->nodo_actual->y == aux->siguiente->nodo_actual->y+1){
                    switch(orientacion){      
                        case(ESTE):
                            robot.para();
                            robot.giraIzquierda();
                            break;        
                        case(OESTE):
                            robot.para();
                            robot.giraDerecha();
                            break;
                        default:
                            break;
                        }
			maze->orientarRobotNorte();
		}else if(aux->nodo_actual->x == aux->siguiente->nodo_actual->x && aux->nodo_actual->y == aux->siguiente->nodo_actual->y-1){
                    switch(orientacion){     
                        case(ESTE):
                            robot.para();
                            robot.giraDerecha();
                            break;        
                        case(OESTE):
                            robot.para();
                            robot.giraIzquierda();
                            break;
                        default:
                            break;
                        }
			maze->orientarRobotSur();
		}else if(aux->nodo_actual->x == aux->siguiente->nodo_actual->x-1 && aux->nodo_actual->y == aux->siguiente->nodo_actual->y){
                    switch(orientacion){
                        case(SUR):
                            robot.para();
                            robot.giraIzquierda();
                            break;       
                        case(NORTE):
                            robot.para();
                            robot.giraDerecha();
                            break;        
                        default:
                            break;
                        }
			maze->orientarRobotEste();
		}else if(aux->nodo_actual->x == aux->siguiente->nodo_actual->x+1 && aux->nodo_actual->y == aux->siguiente->nodo_actual->y){
                    switch(orientacion){
                        case(SUR):
                            robot.para();
                            robot.giraDerecha();
                            break;              
                        case(ESTE):
                            robot.para();
                            robot.giraIzquierda();
                            break;
                        default:
                            break;
                        }
			maze->orientarRobotOeste();
                }

			maze->getPosRobot(&x,&y,&orientacion);

			switch(orientacion){
			case NORTE:
				if(maze->esNorteLibre()){
					maze->avanzaNorte();  
				}else{
					cout << "No existe un camino en la actual orientacion "<< endl;
				}
				break;
			case SUR:
				if(maze->esSurLibre()){
					maze->avanzaSur();
				}else{
					cout << "No existe un camino en la actual orientacion "<< endl;
				}
				break;
			case ESTE:
				if(maze->esEsteLibre()){
					maze->avanzaEste();
				}else{
					cout << "No existe un camino en la actual orientacion "<< endl;
				}
				break;
			case OESTE:
				if(maze->esOesteLibre()){
					maze->avanzaOeste();
				}else{
					cout << "No existe un camino en la actual orientacion "<< endl;
				}
				break;
			default:
				break;
			}
                            robot.leerSensores();
                            robot.logicaEstados();
                            robot.moverActuadores();
                        while(!robot.condicionSalida() && !fin){
                            if(robot.condicionFinal()) fin =true;
                            robot.leerSensores();
                            robot.logicaEstados();
                            robot.moverActuadores();
                            
                        }
            
         

		maze->getPosRobot(&x,&y,&orientacion);

		if(x==5 & y==5){
			cout << "Has llegado al otro extremo del laberinto!"<<endl;
		}
		maze->imprimirLaberinto();
                aux = aux->siguiente;
	}
	
	maze->imprimirCaminoRobot();
	
	cout << "finaliza el programa" << endl;
}




int main(int argc, char * argv[])
{
	//recorrerLaberintoManual();
	ControlRobot robot;
        
        robot.inicializacion();
        while(!robot.condicionInicio());
        
	Laberinto *maze;
	maze = new Laberinto("./xml/Laberinto_exterior.xml");
        maze->imprimirLaberinto();
	
	// Generamos una solucion entre dos puntos origen [0,0] y destino [5,5]
	camino *solucion;
        solucion = maze->encontrarCamino(0,0,5,5); 
	

	//robot.cargarMapa(maze);
	recorrerCamino(solucion, maze);
	
	
//	while(!robot.condicionSalida()){ // <-- Mientras no hayamos completado el "camino"
//		robot.leerSensores();		// <-- Detectamos cruces
//		robot.logicaEstados();		// <-- Decidimos que hacer en cada cruce
//		robot.moverActuadores();	// <-- Nos orientamos en el laberinto
//		robot.imprimirInfo();
//	}
        robot.para();
	robot.finalizacion();
	
	return 0;
}

