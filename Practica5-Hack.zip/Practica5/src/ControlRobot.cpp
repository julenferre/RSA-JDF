// ControlRobot .cpp

#include "ControlRobot.h"
#include<iostream>
#include <ctime>

using namespace std;

// Estados de la l�gica
#define INICIAL 5
#define SIGUE 1
#define BUSCA 0
#define BUSCA_SALTAR_OBSTACULO 13

// Estados para los motores
#define GIRAR_DERECHA 		0
#define GIRAR_IZQUIERDA		1
#define RECTO				2
#define PARADO				3
#define BUSCA_IZQUIERDA 4
#define BUSCA_DERECHA   6
#define INTERSECCION   7
#define SALTAR_OBSTACULO		12

#define DUCT_TAPE_DERECHA(value) (value < 200)
#define DUCT_TAPE_IZQUIERDA(value) (value < 600)
#define DUCT_TAPE_DERECHA_LATERAL(value) (value < 300)
#define DUCT_TAPE_IZQUIERDA_LATERAL(value) (value < 700)

#define DUCT_TAPE_BPFRONT(value) (value == 3)

int angulo_acum=0;
int angulo=0;
int ang_recorrido = 0;
bool cinta = false;
int clifleft = 0;
int clifright = 0;
bool salir = false;
bool d =false;
int distancia = 0;
int distancia_acum = 0;
int distancia_final = 0;
std::clock_t startTime = 0;
bool clock_taken = false;
/**
*	Constructora objeto ControlRobot
*/
ControlRobot::ControlRobot(void)
{
	
}

/**
*	Destructora objeto ControlRobot
*/
ControlRobot::~ControlRobot(void)
{
	
}

/**
* 	Prepara la conexi�n IRobotConnection e inicializa todas
*	las variables que necesitemos en el programa
*/
void ControlRobot::inicializacion(void)
{
	
	int COM_port;
	char puerto[30];
	
	// Solicitamos el puerto COM por entrada est�ndar
	//cout << "Puerto COM: ";
	//cin >> COM_port;
	//sprintf(puerto, "COM%d",COM_port);
	
	sprintf(puerto,"/dev/ttyUSB0");


	robot = new IRobotConnection(puerto);
	
	// Iniciamos la conexi�n
	cout << "Connecting... ";
	robot->connect();
	cout << "Done!!\n" << endl;
	
	// Comando 128 start
	robot->start();
	delay(500); // Esperamos medio segundo a que cambie de modo

	// Comando 132 modo full
	robot->full();
	delay(500); // Esperamos medio segundo a que cambie de modo
	
	estado_actual = INICIAL;
	estado_anterior = INICIAL;
	motores = PARADO;
		
}

/**
* 	Calcula si se han dado las condiciones necesarias para terminar el programa
*	return bool: 
*		- true para terminar
*		- false para continuar al menos un ciclo m�s
*/

//finaliza el autoguiado porque ha encontrado un nodo
bool ControlRobot::condicionSalida()
{
	if(sensores.l && sensores.r){
            cout << "Linea doble!"<< endl;
            cout << "sensor izda"<< sensores.left;
            cout << "sensor dcha!"<< sensores.right;
            return true;
        }
        else return false;
}

//Inicio ejecucion del programa
bool ControlRobot::condicionInicio()
{
	sensores.buttons = robot->updateSensor(iRobotSensors::BUTTONS ); //recibimos la lectura del sensor de botones
        if (sensores.buttons == 1){ //si se trata del boton play
            return true; //indicamos que se ha de iniciar la ejecucion
            robot->updateSensor(iRobotSensors::DISTANCE ); //iniciamos la cuenta de la distancia recorrida por el robot
        }
		else return false; // todavia no se iniciara la ejecucion
}

//final de ejecucion del programa
bool ControlRobot::condicionFinal()
{
	sensores.buttons = robot->updateSensor(iRobotSensors::BUTTONS ); //recibimos la lectura del sensor de botones
        if (sensores.buttons == 4) return true; //si se ha pulsado el boton Advance indicamos que se ha de finalizar el programa
        else return false; // nos mantenemos siempre dentro del bucle
        robot->driveDirect(0,0);
}

/**
*	Obtiene y trata la informaci�n de los sensores relevantes al programa, 
*	para ello usa la struct Sensores_iCreate sensores;
*/
void ControlRobot::leerSensores()
{
	sensores.front_left = robot->updateSensor(iRobotSensors::CLIFFFRONTLEFTSIGNAL );
	// Ajustamos el valor al m�ximo permitido por la especificaci�n OI
	if(sensores.front_left>4095) sensores.front_left=4095;
	
	sensores.fl = DUCT_TAPE_IZQUIERDA(sensores.front_left);
        
        sensores.front_right = robot->updateSensor(iRobotSensors::CLIFFFRONTRIGHTSIGNAL );
	// Ajustamos el valor al m�ximo permitido por la especificaci�n OI
	if(sensores.front_right>4095) sensores.front_right=4095;
	
	sensores.fr = DUCT_TAPE_DERECHA(sensores.front_right);
        
        sensores.left = robot->updateSensor(iRobotSensors::CLIFFLEFTSIGNAL );
	// Ajustamos el valor al m�ximo permitido por la especificaci�n OI
	if(sensores.left>4095) sensores.left=4095;
	
	sensores.l = DUCT_TAPE_IZQUIERDA_LATERAL(sensores.left);
        
        sensores.right = robot->updateSensor(iRobotSensors::CLIFFRIGHTSIGNAL );
	// Ajustamos el valor al m�ximo permitido por la especificaci�n OI
	if(sensores.right>4095) sensores.right=4095;
	
	sensores.r = DUCT_TAPE_DERECHA_LATERAL(sensores.right);
        
        sensores.bumpers = robot->updateSensor(iRobotSensors::BUMPERS_AND_WHEELDROPS );
        sensores.bp3 = DUCT_TAPE_BPFRONT(sensores.bumpers);
}

/**
*	Contiene la l�gica del programa
*/
void ControlRobot::logicaEstados()
{		
	// Actualizamos los estados: 
    if(!clock_taken){
        startTime = std::clock();
        clock_taken=true;
    }
	estado_anterior = estado_actual;		

    if(sensores.bp3) estado_actual = BUSCA_SALTAR_OBSTACULO; //	si se activa el sensor de bumper
        else if(sensores.fl && sensores.fr)estado_actual = SIGUE;
	else if(!sensores.fl && !sensores.fr)estado_actual = SIGUE; //mientras no se vea la linea negra
	else if(sensores.fl) estado_actual = BUSCA_IZQUIERDA; //si el sensor izquierdo ve la linea negra
        else if(sensores.fr) estado_actual = BUSCA_DERECHA; //si el sensor derecho ve la linea negra
	
	// Se decide que hacer con los parametros del robot
	switch(estado_actual){	
		case SIGUE:
			motores = RECTO;
			break;		
		case BUSCA_IZQUIERDA:
			motores = GIRAR_IZQUIERDA;
			break;
                case BUSCA_DERECHA:
			motores = GIRAR_DERECHA;
			break;
		case BUSCA_SALTAR_OBSTACULO:
			motores = SALTAR_OBSTACULO;
			break;
                
		default:
			break;
	}
}

/**
*  	Activa los actuadores correspondientes en funci�n de lo decidido 
*	en la l�gica del programa 
*/
void ControlRobot::moverActuadores()
{
    
	switch(motores){
		case PARADO:
			actuadores.vel_der = 0;
			actuadores.vel_izq = 0;
			break;
		case RECTO:
			actuadores.vel_der = 170;
			actuadores.vel_izq = 170;
			robot->leds( 3, 90,200 );
			break;
		case GIRAR_DERECHA:
			actuadores.vel_der = -50;
			actuadores.vel_izq = 50;
			robot->leds( 3, 0,0 );
			break;
                case GIRAR_IZQUIERDA:
                        actuadores.vel_der = 50;
                        actuadores.vel_izq = -50;
                        robot->leds( 3, 0,0 );
                        break;
                case SALTAR_OBSTACULO:
                    robot->driveDirect(100, -100);
                        angulo = robot->updateSensor(iRobotSensors::ANGLE);
                        while(angulo_acum<30){
                        delay(50);
                        angulo = robot->updateSensor(iRobotSensors::ANGLE);
                        delay(50);
                        angulo_acum = angulo+angulo_acum;   
                        }
                        angulo_acum=0;
						//avanzar recorriendo un circulo en el sentido de las agujas del reloj
                        robot->driveDirect(0, 0);
                        robot->driveDirect(20, 100);
                        while(robot->updateSensor(iRobotSensors::BUMPERS_AND_WHEELDROPS) == 0);//mantener el giro mientras no haya chocado
						//girar 30º a la izquierda por segunda vez
						//se repite el codigo para evitar errores por no haber dejado dejos la linea negra
                        robot->driveDirect(0, 0);
                        robot->driveDirect(100, -100);
                        angulo = robot->updateSensor(iRobotSensors::ANGLE);
                        while(angulo_acum<30){
                        delay(50);
                        angulo = robot->updateSensor(iRobotSensors::ANGLE);
                        delay(50);
                        angulo_acum = angulo+angulo_acum;   
                        }
                        angulo_acum=0;
                        robot->driveDirect(0, 0);
                        robot->driveDirect(20, 100);
                        while(robot->updateSensor(iRobotSensors::BUMPERS_AND_WHEELDROPS) == 0);
                        delay(50);
						//repetir lo anterior, pero esta vez mantenerlo en bucle hasta que encuentre cinta negra
                        while(cinta==false){
							
                            robot->driveDirect(0, 0);
                            robot->driveDirect(100, -100);
                            robot->updateSensor(iRobotSensors::ANGLE);
                            while(angulo_acum<30){
                                delay(50);
                                angulo = robot->updateSensor(iRobotSensors::ANGLE);
                                delay(50);
                                angulo_acum = angulo+angulo_acum;   
                            }
                            angulo_acum=0;
                            robot->driveDirect(0, 0);
                            robot->driveDirect(5, 100);
                            while(robot->updateSensor(iRobotSensors::BUMPERS_AND_WHEELDROPS) == 0 && cinta==false){
                                clifleft = robot->updateSensor(iRobotSensors::CLIFFFRONTLEFTSIGNAL );
                                delay(50);
                                clifright = robot->updateSensor(iRobotSensors::CLIFFFRONTRIGHTSIGNAL );
                                delay(50);
                                if(clifleft <= 200){//si el sensor izquierdo encuentra cinta
                                    cinta=true; //indicamos que hemos evitado el obstaculo
                                   
                                }
                                else if(clifright <= 200){//si el sensor derecho encuentra cinta
                                    cinta=true; //indicamos que hemos evitado el obstaculo
                                    
                                }
                            }
                            

                        }
           
                       //avanzamos 10cm para centrar el robot correctamente en la cinta
                        cinta=false;
                        robot->driveDirect(0, 0);
                        robot->driveDirect(200, 200);
                        distancia = robot->updateSensor(iRobotSensors::DISTANCE);
                        distancia_final=distancia_final+distancia; //añadimos la distancia recorrida a la distancia total para no perder el dato
                        while(distancia_acum<100){
                        delay(50);
                        distancia = robot->updateSensor(iRobotSensors::DISTANCE); 
                        distancia_final=distancia_final+distancia; //añadimos la distancia recorrida a la distancia total para no perder el dato
                        distancia_acum = distancia+distancia_acum;
                        }
                        distancia_acum=0;
						//girar a la izquierda lentamente hasta encontrar la cinta
                        robot->driveDirect(0, 0);
                        robot->driveDirect(50, -50);
                        while(!cinta){
                            clifright = robot->updateSensor(iRobotSensors::CLIFFFRONTRIGHTSIGNAL);
                            if(clifright<=200){//si el sensor derecho encuentra cinta
                            cinta=true;  //terminamos de girar
                        }
                        }
                         cinta=false; 
			break;  
		default:
			break;
	}
	
	robot->driveDirect(actuadores.vel_der, actuadores.vel_izq);
	
}

//Situa el robot en la posicion correcta para realizar un giro (centra el robot en el nodo) y lo detiene
void ControlRobot::para()
{
    robot->driveDirect(150,150);
    robot->updateSensor(iRobotSensors::DISTANCE );
    while(!d){ //mientras no haya alcanzado la distancia deseada el robot avanza
        distancia =  robot->updateSensor(iRobotSensors::DISTANCE );
        distancia_acum=distancia_acum + distancia;
        if (distancia_acum >= 30) d=true;        
    }
    distancia_acum=0;
    d=false;
    robot->driveDirect(0,0);//una vez alcanzada la distancia deseada el robot se detiene
    
}

//funcion que permite al robot girar 180º sobre su posicion
void ControlRobot::gira180(void)
{
    robot->updateSensor(iRobotSensors::ANGLE);
    robot->driveDirect(50,-50);
    while(!cinta){//mientras no haya detectado la cinta del lado opuesto
		//se lee el sensor para comprobar si ha detectado linea
        sensores.front_left = robot->updateSensor(iRobotSensors::CLIFFFRONTLEFTSIGNAL );
		/*se indicara que el robot ha detectado linea solo si ha sobreparado los 90º de giro
		  de esta manera se evita que se detenga en una linea incorrecta*/
        if(angulo_acum >90) cinta = DUCT_TAPE_IZQUIERDA(sensores.front_left);
        angulo = robot->updateSensor(iRobotSensors::ANGLE);//obtener el angulo recorrido
        angulo_acum = angulo+angulo_acum;//se acumula el angulo recogido al total
        }
    angulo_acum=0;  
    cinta=false;
    robot->driveDirect(0,0);
}

/*funcion que permite al robot girar 90º sobre su posicion
  esta funcion actua de forma similar a la funcion gira180(),
  pero en este caso el robot recorrera 90º*/
void ControlRobot::giraDerecha(void)
{
    robot->updateSensor(iRobotSensors::ANGLE);
    delay(50);
    robot->driveDirect(-50,50);
    while(!cinta){//mientras no haya detectado la cinta del lado opuesto
		//se lee el sensor para comprobar si ha detectado linea
        sensores.front_left = robot->updateSensor(iRobotSensors::CLIFFFRONTLEFTSIGNAL );
		/*se indicara que el robot ha detectado linea solo si ha sobreparado los 45º de giro
		  de esta manera se evita que se detenga en una linea incorrecta*/
        if(angulo_acum >45) cinta = DUCT_TAPE_IZQUIERDA(sensores.front_left);
        delay(100);
        ang_recorrido = robot->updateSensor(iRobotSensors::ANGLE);//obtener el angulo recorrido
		//como el giro es a la derecha esta funcion es necesaria para lograr el valor real de angulo
        angulo = 65536 - ang_recorrido;
        angulo_acum = angulo+angulo_acum;//se acumula el angulo recogido al total
        cout << "angulo_acum " << angulo << endl;
        }
    angulo_acum=0;
    cinta=false;
    robot->driveDirect(0,0);
}

/*funcion que permite al robot girar 90º sobre su posicion
  esta funcion actua de forma similar a la funcion gira180(),
  pero en este caso el robot recorrera 90º*/
void ControlRobot::giraIzquierda(void)
{
    robot->updateSensor(iRobotSensors::ANGLE);
    delay(50);
    robot->driveDirect(50,-50);
    while(!cinta){
		//mientras no haya detectado la cinta del lado opuesto
		//se lee el sensor para comprobar si ha detectado linea
        sensores.front_right = robot->updateSensor(iRobotSensors::CLIFFFRONTRIGHTSIGNAL );
		/*se indicara que el robot ha detectado linea solo si ha sobreparado los 45º de giro
		  de esta manera se evita que se detenga en una linea incorrecta*/
        if(angulo_acum >45) cinta = DUCT_TAPE_DERECHA(sensores.front_right);
         delay(50);
        angulo = robot->updateSensor(iRobotSensors::ANGLE);//obtener el angulo recorrido
        angulo_acum = angulo+angulo_acum;//se acumula el angulo recogido al total
        }
    angulo_acum=0;  
    cinta=false;
    robot->driveDirect(0,0);
}
/**
*	Muestra informaci�n relevante al usuario
*/
void ControlRobot::imprimirInfo(void)
{
	char estado[20];
	switch(estado_actual){
		case INICIAL : 	sprintf(estado,"INICIAL");	break;
		case SIGUE : 	sprintf(estado,"SIGUE");	break;
		case BUSCA : 	sprintf(estado,"BUSCA");	break;
	}
	
	printf("Estado: %s ",estado);
	printf(": %s ", sensores.fl ? "true" : "false");
	printf(" Valor: %d",	sensores.front_left);
	printf("\n");
}

/**
*	Cierra conexiones abiertas
*/
void ControlRobot::finalizacion(void)
{
	robot->disconnect();
	delete robot;
}

